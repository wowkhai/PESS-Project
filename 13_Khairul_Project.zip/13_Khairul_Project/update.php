<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Police Emergency Service System</title>
<link href="stylesheet.css" rel="stylesheet" type="text/css">

<!-- CSS for Step by Step Menu -->
<style> 
a.logcallcircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #ECE5E5;
    color: #ECE5E5;
    }

a.dispatchcircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #ECE5E5;
    color: #ECE5E5;
}

a.updatecircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #8BC34A;
    color: #8BC34A;
}

a.historycircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #ECE5E5;
    color: #ECE5E5;
}
</style>
	<link href="stylesheet.css" rel="stylesheet" type="text/css"> <!-- CSS Stylesheet -->
    
<?php 
if(isset($_POST['updatebtn'])){
	require_once 'db.config.php';
	
	$mysqli = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
	
	if($mysqli->connect_errno) {
		die("ERROR - MySQL Connection: ".$mysqli->connect_errno);
	}
	
	$sql = "UPDATE patrolcar SET patrolcarStatusId = ? WHERE patrolcarId = ?";
	
	if(!($stmt = $mysqli->prepare($sql))) {
		die("ERROR - Preparing failed: ".$mysqli->errno);
	}
	
	if (!$stmt->bind_param('ss', $_POST['patrolCarStatus'], $_POST['patrolCarId'])) {
		die("ERROR - Binding param failed: ".$stmt->errno);
	}
	
	if (!$stmt->execute()){
		die("ERROR - Updating patrolcar table failed: ".$stmt->errno);
	}
	
	if ($_POST["patrolCarStatus"] == '4') {
		
		$sql = "UPDATE dispatch SET timeArrived = NOW()
		WHERE timeArrived is NULL AND patrolcarId = ?";
		
		if(!($stmt = $mysqli->prepare($sql))) {
			die("ERROR - Preparing Failed: ".$mysqli->errno);
		}
		
		if(!$stmt->bind_param('s',$_POST['patrolCarId'])){
			die("ERROR - Binding param failed: ".$stmt->errno);
		}
		
		if(!$stmt->execute()){
			die("ERROR - Updating dispatch table failed: ".$stmt->errno);
		}
        
	} else if ($_POST["patrolCarStatus"] == '3') {
		$sql = "SELECT incidentId FROM dispatch WHERE timeCompleted IS NULL AND patrolcarId = ?";
		
		if(!($stmt = $mysqli->prepare($sql))) {
			die("ERROR - Error preparing: ".$mysqli->errno);
		}
		
		if (!$stmt->bind_param('s', $_POST['patrolCarId'])) {
			die("ERROR - Error binding parameter: ".$stmt->errno);
		}
		
		if (!$stmt->execute()){
			die("ERROR - Error updating patrolcar table: ".$stmt->errno);
		}
		
		if (!($resultset = $stmt->get_result())) {
			die("ERROR - Error getting result set: ".$stmt->errno);
		}
		
		$incidentId;
		
		while($row = $resultset->fetch_assoc()) {
		$incidentId = $row['incidentId'];
		}
	
		$sql = "UPDATE dispatch SET timeCompleted = NOW()
				WHERE timeCompleted is NULL AND patrolcarId = ?";
	
			if(!($stmt = $mysqli->prepare($sql))) {
				die("ERROR - Preparing (L129): ".$mysqli->errno);
			}
		
			if (!$stmt->bind_param('s', $_POST['patrolCarId'])) {
				die("ERROR - Binding Param (L133): ".$stmt->errno);
			}
		
			if (!$stmt->execute()){
				die("ERROR - Updating dispatch table (L137): ".$stmt->errno);
			}
		
			$sql = "UPDATE incident SET incidentStatusId = '3' WHERE incidentId = '$incidentId' AND NOT EXISTS (SELECT * FROM dispatch WHERE timeCompleted IS NULL and incidentId = '$incidentId')";
		
			if(!($stmt = $mysqli->prepare($sql))) {
				die("ERROR - Error preparing: ".$mysqli->errno);
			}
			
			if (!$stmt->execute()){
				die("ERROR - Error updating dispatch table: ".$stmt->errno);
			}
			
			$resultset->close();
		
	}
	$stmt->close();
	$mysqli->close();
	?>
	
<script>window.location="logcall.php";</script>
<?php } ?>
</head>


<body>
<div class = "OverallBackground">

<!-- Top Bar -->
<div id = "square"></div>
    
<!-- Navigation Bar (.Navigation) -->
<?php require 'nav.php';?> 
    
<!-- PESS Banner -->
<img src="Media/pessbannerv2.jpg" width="750" alt="PESS Banner"/ id="Center">	
    
<br>
<br>
    
<?php
if (!isset($_POST["btnsearch"]))
{
?>

<form name="searchform" method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?> ">
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr></tr>
<tr>
<td>Patrol Car ID: </td>
<td><input type="text" name="patrolCarId" id="patrolCarId"></td>
<td><input type="submit" name="btnsearch" id="btnsearch" value="Search"></td>
</tr>
</table>
</form>
<?php }
	
else {
	require_once 'db.config.php';
	
	$mysqli = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
	
	if ($mysqli->connect_errno) {
		die("ERROR - Error connecting to MySQL: ".$mysqli->connect_errno);
	}
	
	$sql = "SELECT * FROM patrolcar WHERE patrolcarId = ?";
	
	if (!($stmt = $mysqli->prepare($sql))){
		die("ERROR - Error preparing: ".$mysqli->errno);
	}
	
	if (!$stmt->bind_param('s', $_POST['patrolCarId'])){
		die("ERROR - Error binding parameters: ".$stmt->errno);
	}
	
	if (!$stmt->execute()){
		die("ERROR - Error executing: ".$stmt->errno);
	}
	if (!($resultset = $stmt->get_result())) {
		die("ERROR - Error getting result set: ".$stmt->errno);
	}
	
	if($resultset->num_rows == 0) {
		?>
		<script>window.location="update.php";
		alert("Invalid Patrol Car ID");</script>
		<?php
	}
	
	$patrolCarId;
	$patrolCarStatusId;
	
	while($row = $resultset->fetch_assoc()) {
		$patrolCarId = $row['patrolcarId'];
		$patrolCarStatusId = $row['patrolcarStatusId'];
	}
	
	$sql = "SELECT * FROM patrolcar_status";
	if(!($stmt = $mysqli->prepare($sql))) {
		die("ERROR - Preparing Failed: ".$mysqli->errno);
	}
	
	if (!$stmt->execute()) {
		die("ERROR - Executing: ".$stmt->errno);
	}
	if (!($resultset = $stmt->get_result())) {
		die("ERROR - Getting result set: ".$stmt->errno);
	}
	
	$patrolCarStatusArray;;
	
	while ($row = $resultset->fetch_assoc()) {
	$patrolCarStatusArray[$row['statusId']] =$row['statusDesc'];
	}
	
	$stmt->close();
	
	$resultset->close();
	
	$mysqli->close();
?>
	
<form name="updateform" method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?> ">

	<table border="0" align="center" cellpadding="4" cellspacing="4">
	<tr></tr>
	<tr>
	<td>ID :</td>
	<td><?php echo $patrolCarId ?>
		<input type="hidden" name="patrolCarId" id="patrolCarId" value="<?php echo $patrolCarId ?>">
	</td>
	</tr>
	<tr>
		<td>Status :</td>
		<td><select name="patrolCarStatus" id="patrolCarStatus">
		<?php foreach($patrolCarStatusArray as $key => $value){?>
		<option value="<?php echo $key ?>"
				<?php if ($key==$patrolCarStatusId) {?> selected="selected"
		<?php } ?>
	>
		<?php echo $value ?>
		</option>
		<?php } ?>
		</select></td>
	</tr>
	<tr>
		<td><input type="reset" name="cancelbtn" id="cancelbtn" value="Reset"></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="updatebtn" id="updatebtn" value="Update"></td>
	</tr>
	</table>
	
</form>
<?php } ?>
</body>
</html>