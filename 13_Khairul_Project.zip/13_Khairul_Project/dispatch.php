<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Police Emergency Service System</title>
    
<!-- CSS for StepbyStep Menu -->
<style> 
    
a.logcallcircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #ECE5E5;
    color: #ECE5E5;
    }

a.dispatchcircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #8BC34A;
    color: #8BC34A;
}

a.updatecircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #ECE5E5;
    color: #ECE5E5;
}

a.historycircle {
    width: 50px;
    height: 50px;
    font-weight: bold;
    border-radius: 100px;
    display: inline-block;
    line-height: 50px;
    border-style: solid;
    border-color: #ECE5E5;
    color: #ECE5E5;
}
</style>
	<link href="stylesheet.css" rel="stylesheet" type="text/css"> <!-- CSS Stylesheet -->
</head>
<body>
<div class = "OverallBackground">

<!-- Top Bar -->
<div id = "square"></div>
    
<!-- Navigation Bar (.Navigation) -->
<?php require 'nav.php';?> 
    
<!-- PESS Banner -->
<img src="Media/pessbannerv2.jpg" width="750" alt="PESS Banner"/ id="Center">	
    

<?php 
    
if (isset($_POST["btnDispatch"]))
{	
	require_once 'db.config.php';
	
	$mysqli = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
    
	if ($mysqli->connect_errno)
	{
		die("Failed to connect to MySQL: ".$mysqli->connect_errno);
	}
	
	$patrolcarDispatched = $_POST["chkPatrolcar"];
	$numOfPatrolcarDispatched = count($patrolcarDispatched);
	
	$incidentStatus;
	if ($numOfPatrolcarDispatched > 0) {
		$incidentStatus='2';
	} else {
		$incidentStatus='1';
	}
	
	$sql = "INSERT INTO incident (callerName, phoneNumber, incidentTypeId, incidentLocation, incidentDesc, incidentStatusId) VALUES (?, ?, ?, ?, ?, ?)";
	
	if (!($stmt = $mysqli->prepare($sql)))
	{
		die("Prepare failed: ".$mysqli->errno);
	}
	
	if (!$stmt->bind_param('ssssss', $_POST['callerName'],
						  $_POST['contactNo'],
						  $_POST['incidentType'],
						  $_POST['location'],
						  $_POST['incidentDesc'],
						  $incidentStatus))
	
	{ 
		die("Binding parameters failed: ".$stmt->errno);
	}
	
	if (!$stmt->execute())
	{
		die("Insert incident table failed: ".$stmt->errno);
	}
    
    //Retrieve incident_id for the newly inserted incident
	$incidentId=mysqli_insert_id($mysqli);;
	
    //Update patrolcar status table & add into dispatch table
	for($i=0; $i < $numOfPatrolcarDispatched; $i++)
	{	
        //Update patrol car status
		$sql = "UPDATE patrolcar SET patrolcarStatusId ='1' WHERE patrolcarId = ?";
		
		if (!($stmt = $mysqli->prepare($sql))) { 
			die("ERROR - Prepare failed: ".$mysqli->errno);
		}
	
		if (!$stmt->bind_param('s', $patrolcarDispatched[$i])){ 		
			die("ERROR - Binding parameters failed: ".$stmt->errno);	
		}
	
		if (!$stmt->execute()){ 	
			die("ERROR- Update patrolcar_status table failed: " .$stmt->errno);	
		}
	   
        //Insert dispatch data
		$sql = "INSERT INTO dispatch (incidentId, patrolcarId, timeDispatched) VALUES (?, ?, NOW())";
	   
		if (!($stmt = $mysqli->prepare($sql))) {
			die("ERROR- Prepare failed: ".$mysqli->errno);

		}
		
		if (!$stmt->bind_param('ss', $incidentId,
							  		$patrolcarDispatched[$i])){
			die("ERROR - Binding parameters failed: ".$stmt->errno);	
		}
	
	
		if (!$stmt->execute()) {
			die("ERROR - Insert dispatch table failed: ".$stmt->errno);
		}
	
	}
		

	$stmt->close();
	$mysqli->close();
    
	?>
	
<script>window.location="update.php";</script>
<?php } ?>
    
<!-- Dispatch Form - Form 1-->
    
<form name="form1" method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?> ">
    <table align="center">
	<tr>
		<td colspan="2"><strong>Incident Detail</strong></td>
	</tr>  
	<tr>
		<td><strong>Caller's Name :</strong></td>
		<td><?php echo $_POST['callerName'] ?> 
			<input type="hidden" name="callerName" id="callerName" 
			style="background-color: #eeeeee" value="<?php echo $_POST['callerName'] ?>"></td>
	</tr>
	<tr>
		<td><strong>Contact No :</strong></td>
		<td><?php echo $_POST['contactNo'] ?> 
			<input type="hidden" name="contactNo" id="contactNo" 
			style="background-color: #eeeeee" value="<?php echo $_POST['contactNo'] ?>"></td>
	</tr>
	<tr>
		<td><strong>Location :</strong></td>
		<td><?php echo $_POST['location'] ?> 
			<input type="hidden" name="location" id="location" 
			style="background-color: #eeeeee" value="<?php echo $_POST['location'] ?>"></td>
	</tr>
	<tr>
		<td><strong>Incident Type :</strong></td>
		<td><?php echo $_POST['incidentType'] ?> 
			<input type="hidden" name="incidentType" id="incidentType" style="background-color: #eeeeee" value="<?php echo $_POST['incidentType'] ?>"></td>
	</tr>
	<tr>
		<td><strong>Incident Description :</strong></td>
		<td><textarea name="incidentDesc" cols="45" rows="5" readonly id="incidentDesc" style="background-color: #eeeeee"><?php echo $_POST['incidentDesc'] ?></textarea><input name="incidentDesc" type="hidden" id="incidentDesc" value="<?php echo $_POST['incidentDesc'] ?>"></td>
    </tr>
</table>
	<?php require_once 'db.config.php';

$mysqli = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
if ($mysqli->connect_errno) {
	die("Failed to connect to MYSQL: ".$mysqli->connect_errno);
}

$sql = "SELECT patrolcarId, statusDesc FROM patrolcar JOIN patrolcar_status
ON patrolcar.patrolcarStatusId=patrolcar_status.StatusId
WHERE patrolcar.patrolcarStatusId='2' OR patrolcar.patrolcarStatusId='3'";

if (!($stmt = $mysqli->prepare($sql))) {
	die("Prepare failed: ".$mysqli->errno);
}

if (!$stmt->execute()){
	die("Error Executing: ".$stmt->errno);
}

			
if (!($resultset = $stmt->get_result())) {
	die("Error getting result set : ".$stmt->errno);
}

$patrolcarArray;
			
while($row = $resultset->fetch_assoc()) {
	$patrolcarArray[$row['patrolcarId']] = $row['statusDesc'];
}

$stmt->close();

$resultset->close();

$mysqli->close();	
?>
		
<br><br>
<table border="1" align="center">
	<tr>
		<td colspan="3">Dispatch Patrolcar Panel</td>
	</tr>
	<?php
		foreach($patrolcarArray as $key=>$value){
	?>
	<tr>
		<td><input type="checkbox" name="chkPatrolcar[]"
			value="<?php echo $key ?>"></td>
		<td><?php echo $key ?></td>
		<td><?php echo $value ?></td>
		</tr>
		<?php } ?>
		<tr>
		<td><input type="Reset" name="btnCancel" id="btnCancel" value="Reset"></td>
		<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="Submit" name="btnDispatch" id="btnDispatch" value="Dispatch"></td>
		</tr>
</table>
</form>
</fieldset>	
    </div>
</body>
</html>